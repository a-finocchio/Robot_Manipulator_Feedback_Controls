%the following is the function code for ROTY
function A = ROTY(beita)

A = [cos(beita) 0 sin(beita);
     0 1 0;
     -sin(beita) 0 cos(beita)];
end
