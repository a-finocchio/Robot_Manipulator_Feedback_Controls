%the following is the function code for ROTZ
function A = ROTZ(beita)

A = [cos(beita) -sin(beita) 0 ;
     sin(beita) cos(beita)  0;
     0          0           1];
end
